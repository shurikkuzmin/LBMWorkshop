#include <iostream>

using namespace std;

extern "C" void check_result(float* r, unsigned int n)
{
    bool passed = true;
    for(unsigned int i = 0; passed && i < n; ++i)
        passed = r[i] == 3.0f*i;

    cout << "\tCorrect result: " << (passed?"YES":"NO") << endl;
}

